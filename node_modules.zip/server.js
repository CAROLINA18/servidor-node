const express = require('express');
const mongoose = require('mongoose');
const app = express();
app.use(express.json());

// Conectar a MongoDB
mongoose.connect('mongodb://localhost:27017/notificaciones')
    .then(() => console.info('Conexión a MongoDB establecida correctamente'))
    .catch(err => console.error('Error al conectar a MongoDB:', err));

// Definir el esquema de notificación
const notificationSchema = new mongoose.Schema({
    group: String,
    sender: String,
    message: String,
    dateTime: Date,
    additionalInfo: Object // Puedes agregar más información aquí
});

const Notification = mongoose.model('Notification', notificationSchema);

// Ruta para guardar la notificación
app.post('/saveNotification', (req, res) => {
    const newNotification = new Notification(req.body);
    newNotification.save()
        .then(() => res.status(200).send('Notificación guardada'))
        .catch(err => res.status(500).send('Error al guardar la notificación: ' + err));
});

// Iniciar el servidor en el puerto 3000
app.listen(3000, '0.0.0.0', () => {
    console.log('Servidor escuchando en el puerto 3000');
  });